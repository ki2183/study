import { Point } from "./point.js";

export class Wave{
    constructor(wave_point,color){
        this.wave_point=wave_point;
        this.color=color
        this.points=[];
    }
    resize(stageWidth,stageHeight){
        this.stageWidth=stageWidth;
        this.stageHeight=stageHeight;

        this.centerX=this.stageWidth/2;
        this.centerY=this.stageHeight/10;

        this.pointGap=this.stageWidth/(this.wave_point-1);

        this.init()
    }
    init(){
        for(let i=0; i<this.wave_point; i++){
            this.points[i]=new Point(
                this.pointGap*i,
                this.centerY,
                i
            );
        }
    }
    draw(ctx){
        ctx.fillStyle=this.color;
        ctx.beginPath();

        let preX=this.points[0].x;
        let preY=this.points[0].y;

        ctx.moveTo(preX,preY);

        for(let i=1; i<this.wave_point; i++){
            if(i<this.wave_point-1)
                this.points[i].bounce();

            const cx=(preX+this.points[i].x)/2;
            const cy=(preY+this.points[i].y)/2;

            ctx.quadraticCurveTo(preX,preY,cx,cy);

            preX=this.points[i].x;
            preY=this.points[i].y;
        }
        ctx.lineTo(preX,preY);
        ctx.lineTo(this.stageWidth,this.stageHeight);
        ctx.lineTo(this.points[0].x,this.stageHeight);
        ctx.lineTo(this.points[0].x,this.points[0].y);
        ctx.fill();
    }

}