import { Wave } from "./wave.js";
import { Animate_up } from "./animate_up.js";
import { Anim_btn } from "./anim_btn.js";
class App{
    constructor(){
        this.btn_div=document.querySelector('.btn_canvas_ground');

        this.canvas=document.createElement('canvas');
        this.ctx=this.canvas.getContext('2d');
        this.div=document.querySelector('.hidden_div');
        this.div.appendChild(this.canvas);
        this.opaticy=1;
        this.color=`rgba(241, 177, 49,${this.opaticy})`;

        window.addEventListener('resize', this.resize.bind(this),false);
        this.resize();

        this.mouseEvent();

        this.animate_up=new Animate_up(this.stageWidth,this.stageHeight,50,this.div);

        requestAnimationFrame(this.animate.bind(this));

    }
    resize(){
        this.stageWidth=document.body.clientWidth;
        this.stageHeight=document.body.clientHeight;

        this.canvas.width=this.stageWidth*2;
        this.canvas.height=this.stageHeight*2;

        this.ctx.scale(2,2);
        
        this.wave=new Wave(6,this.color);
        this.wave.resize(this.stageWidth,this.stageHeight);
        
        this.anim_btn= new Anim_btn(this.stageWidth,this.stageHeight,this.btn_div);
        this.anim_btn.resize();
    }
    animate(){
        requestAnimationFrame(this.animate.bind(this));
        this.ctx.clearRect(0,0,this.stageWidth,this.stageHeight);
        this.wave.draw(this.ctx);
        
        this.anim_btn.draw(this.overcheck,this.clickcheck);

        if(this.clickcheck===true){
            this.div.style.display="block";
            this.animate_up.animate(this.btn_div,this.clickcheck,this.opaticy);
        }
    }
    mouseEvent(){
        this.overcheck=false;
        this.clickcheck=false;
        this.btn_div.addEventListener('mouseover',this.mouseover.bind(this),false);
        this.btn_div.addEventListener('mouseout',this.mouseout.bind(this),false);
        this.btn_div.addEventListener('mousedown',this.mousedown.bind(this),false);
        this.btn_div.addEventListener('mouseup',this.mouseup.bind(this),false);

    }
    mouseover(e){
        this.overcheck=true;
    }
    mouseout(e){
        this.overcheck=false;
    }
    mousedown(e){
        this.clickcheck=true;
    }
    mouseup(e){
        // this.clickcheck=false;
    }
}
window.onload=()=>{
    new App();
}