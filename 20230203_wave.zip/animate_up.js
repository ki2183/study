export class Animate_up{
    constructor(stageWidth,stageHeight,speed,div){
        this.stageWidth=stageWidth;
        this.stageHeight=stageHeight;

        this.vx=speed;
        this.vy=speed;

        this.x=this.stageWidth;
        this.y=this.stageHeight;

        this.count=0;
        this.bounceratio=3;

        this.wallheight=this.stageHeight/4;

        this.div=div;

        this.check=false;

        this.opaticy;

    }
    animate(button,clickcheck,opaticy){
        const minY=0;
        const maxY=this.stageHeight;
        
        this.y-=this.vy

        if(this.y<this.wallheight){
            if(!this.check){
                this.vy*=0.6;
                this.check=true;
            }            
        }
        
       
        
        if(this.y>-this.stageHeight/4) {
            this.div.style.top=`${this.y}px`;                 
            if(-this.stageHeight/4+20>this.y ||clickcheck===true){
                button.style.display='none';
                clickcheck=false;
                
            }
        }
            
            
    
        
       
    }
}