export class Anim_btn{
    constructor(stageWidth,stageHeight,btn_div){
        this.stageWidth=stageWidth/10;
        this.stageHeight=stageHeight/10;
        this.btn=btn_div;

        this.canvas=document.createElement('canvas');
        this.ctx=this.canvas.getContext('2d');
        this.btn.appendChild(this.canvas);

        this.arcSize=150;

        this.speed=1;
    }
    resize(){
        this.btn.style.width=`${this.stageWidth}px`;
        this.btn.style.height=`${this.stageWidth}px`;

        this.canvas.width=this.stageWidth*2;
        this.canvas.height=this.stageWidth*2;

        this.ctx.scale(2,2);
    }
    draw(overcheck,clickcheck){
        this.mouseover(overcheck);
        this.ctx.fillStyle=`rgb(241, 177, 49)`
        this.ctx.beginPath();
        this.ctx.arc(this.stageWidth/2,this.stageWidth/2,this.arcSize,0,Math.PI*2);
        this.ctx.fill();
    }
    mouseover(overcheck){
        
        if(overcheck==false){
            if(this.arcSize>150&&this.arcSize<=200)
                this.arcSize=150;
        }
        else{
            if(this.arcSize<200)
                this.arcSize+=5;
        }
    }
}