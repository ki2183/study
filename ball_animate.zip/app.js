import { Ball } from "./ball.js";

class App{
    constructor(){
        this.canvas_base=document.querySelector('.canvas_base_div');

        this.canvas=document.createElement('canvas');
        this.ctx=this.canvas.getContext('2d');
        this.canvas_base.appendChild(this.canvas);

        window.addEventListener('resize', this.resize.bind(this));
        this.resize();

        this.event_zip();
       
        this.ball= new Ball(this.stageWidth,this.stageHeight,100,40);

        requestAnimationFrame(this.animate.bind(this));
    }
    resize(){
        this.stageWidth=document.body.clientWidth*0.5;
        this.stageHeight=document.body.clientHeight*0.5;

        this.canvas_base.style.width=`${this.stageWidth}px`
        this.canvas_base.style.width=`${this.stageHeight}px`

        this.canvas.width=this.stageWidth*2;
        this.canvas.height=this.stageHeight*2;

        this.ctx.scale(2,2);
    }
    animate(){
        requestAnimationFrame(this.animate.bind(this));
        this.ctx.clearRect(0,0,this.stageWidth,this.stageHeight);
        this.ball.draw(this.ctx,this.cursorX,this.cursorY,this.moveX,this.click_check);
    }

    event_zip(){
        this.click_check=false;
        this.moveX=0;

        this.canvas.addEventListener('mousedown',this.mousedown.bind(this),false);
        this.canvas.addEventListener('mousemove',this.mousemove.bind(this),false);
        this.canvas.addEventListener('mouseup',this.mouseup.bind(this),false);

    }

    mousedown(e){
        this.click_check=true;
        this.offsetX=e.offsetX;
        this.cursorX=e.offsetX;
        this.cursorY=e.offsetY;
    }
    mousemove(e){
        if(this.click_check)
            this.moveX=e.offsetX-this.offsetX;
            this.cursorX=e.offsetX;
            this.cursorY=e.offsetY;
            this.offsetX=e.offsetX;
            
    }
      mouseup(e){
        this.click_check=false;
        this.cursorX=e.offsetX;
        this.cursorY=e.offsetY;
        
    }

}

window.onload=()=>{
    new App();
}