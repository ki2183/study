export class Point{
    constructor(x,y,index){
        this.x=x;
        this.y=y;
        this.fixedY=y;
        this.cur=index;
        this.speed=0.1;
        this.max=Math.random()*150+100;
    }
    bounce(){
        this.cur+=this.speed;
        this.y=this.fixedY+Math.sin(this.cur)*this.max;
    }
}