export class Ball{
    constructor(stageWidth,stageHeight,radius,speed){
        this.stageWidth=stageWidth;
        this.stageHeight=stageHeight;
        this.radius=radius;
        this.speed=speed;

        this.x=radius*2+(Math.random()*stageWidth-radius*2);
        this.y=radius*2+(Math.random()*stageHeight-radius*2);

        this.vx=this.speed;
        this.vy=this.speed;

        this.color=RandomColor();

        this.bounce_ratio=3;
        this.count=0;
    }
    draw(ctx,curserX,curserY,moveX,click_check,running){
        this.move(curserX,curserY,moveX,click_check)

        ctx.fillStyle='blue';
        ctx.beginPath();
        ctx.arc(this.x,this.y,this.radius,0,Math.PI*2);
        ctx.fill();
    }
    move(curserX,curserY,moveX,click_check){
        if(click_check==true){
            this.x=curserX;
            this.y=curserY;

            this.bounce_ratio=3;
            this.count=0;
            this.vx=moveX/2;
            this.vy=this.speed;
            
        }
        else{
            const maxX=this.stageWidth-this.radius;
            const minX=this.radius;
            const maxY=this.stageHeight-this.radius;
            const minY=this.radius;

            this.y+=this.vy;
            this.x+=this.vx;
            this.vy*=0.92;
            this.vx*=0.92;
            this.vy+=4;

            if(this.y>maxY||this.y<minY){
                this.vy*=-1;
                if(this.count<4){
                    this.count++;
                }
            }
            if(this.x>maxX||this.x<minX){
                this.vx*=-1;
            }

            if(this.count==4){
                this.vy=0;
                this.bounce_ratio=0;
            }
        }
    }
}
function RandomColor(){
    let color='#';
    const colorlist=[1,2,3,4,5,6,7,8,9,'a','b','c','d','e','f'];

    for(let i=0; i<6; i++){
        color+=Math.ceil(Math.random()*14);
    }

    return color;
}